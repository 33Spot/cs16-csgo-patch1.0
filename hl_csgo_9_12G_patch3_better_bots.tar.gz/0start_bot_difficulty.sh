#!/bin/env bash

# Define paths relative to the script location
SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"
CHOSEN_TXT="$SCRIPT_DIR/game/game_info/data/Counter Strike 1.6 CSGO/cstrike/chosen.txt"
TARGET_DIR="$SCRIPT_DIR/game/game_info/data/Counter Strike 1.6 CSGO/cstrike"
BACKUP_DIR="$SCRIPT_DIR/game/game_info/data/Counter Strike 1.6 CSGO/cstrike"  # Assuming backups are here

# Initialize last_desc
last_desc="None"

# Read the last description if the file exists and isn't empty
if [ -f "$CHOSEN_TXT" ] && [ -s "$CHOSEN_TXT" ]; then
    last_desc=$(cat "$CHOSEN_TXT")
fi

# Array of filenames
filenames=(
"BotProfile.db_backup_relax"
"BotProfile.db_backup_strike2"
"BotProfile.db_backup_online"
"BotProfile.db_backup_strike1"
"BotProfile.db_backup_strike3"
"BotProfile.db_backup_strike4"
"BotProfile.db_backup_test"
"BotProfile.db_backup_champion"
"botprofile.db_champion.1.3.1"
)

# Array of descriptions
descriptions=(
"bots relaxed"
"bots like on online server strike2"
"bots like on online server"
"bots like on online server strike1"
"bots like on online server strike3"
"bots like on online server strike4"
"bots like on online server test"
"bots like on championships"
"bots like on championships 1.3.1"
)

# Create the menu options
options=()
for i in "${!descriptions[@]}"; do
    options+=("$i" "${descriptions[$i]}")
done

# Show the dialog menu
choice=$(dialog --title "Bot Profile Selector" \
               --menu "Last selected: $last_desc\n\nChoose a bot profile:" \
               18 55 16 "${options[@]}" \
               3>&1 1>&2 2>&3)

# Check if user pressed Cancel or ESC
if [ $? -ne 0 ]; then
    clear
    echo "No selection made."
    exit
fi

# Clear the screen after dialog
clear

# Process the choice
chosen_filename="${filenames[$choice]}"
chosen_description="${descriptions[$choice]}"
echo "You chose: $chosen_filename ($chosen_description)"

# Save the chosen description to chosen.txt
mkdir -p "$(dirname "$CHOSEN_TXT")"
echo "$chosen_description" > "$CHOSEN_TXT"

# Copy the selected file
SOURCE_FILE="$BACKUP_DIR/$chosen_filename"
if [ -f "$SOURCE_FILE" ]; then
    cp -f "$SOURCE_FILE" "$TARGET_DIR/BotProfile.db"
    echo "Successfully copied $chosen_filename to BotProfile.db"
else
    echo "Error: File $chosen_filename not found in $BACKUP_DIR" >&2
    echo "Available files in $BACKUP_DIR:"
    ls -1 "$BACKUP_DIR"/BotProfile.db_*
    exit 1
fi
