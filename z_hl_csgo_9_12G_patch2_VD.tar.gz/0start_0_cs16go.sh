#!/bin/sh
# Check if dialog is installed, if not install it
if ! command -v dialog >/dev/null 2>&1; then
    echo "dialog is not installed. Installing..."
#    if command -v sudo >/dev/null 2>&1; then
        sudo apt-get update && sudo apt-get install -y dialog
        exit 1
    else
#        echo "Error: sudo not found. Please install 'dialog' manually."
            echo ""
#        exit 1
#    fi
fi

    bash ./game/script/set_0_.sh
main_menu() {

    bash ./game/script/0killler.sh






resolution=$(xrandr | grep "*" | awk '{ print $1 }' | head -1)
sed -i -E "/^vd=/ { s/[0-9]+x[0-9]+[ ]*//; s/vd=[ ]*/vd=$resolution /; }" ./game/game_info/winetricks_list.txt -i







# Array of filenames
filenames="game_info.run
game_info.mul"


# Array of descriptions
descriptions="Counter Strike 1.6 CSGO
Counter Strike 1.6 CSGO - JOIN other server"

    # Create menu options
    i=0
    options=""
    while [ $i -lt $(echo "$filenames" | wc -l) ]; do
        filename=$(echo "$filenames" | sed -n "$((i + 1))p")
        description=$(echo "$descriptions" | sed -n "$((i + 1))p")
        options="$options $i \"$description\""
        i=$((i + 1))
    done

    # Show the dialog menu
    choice=$(eval "dialog --cancel-label 'Quit' --menu 'Choose a game' 20 60 15 $options 3>&1 1>&2 2>&3 3>&-")
    clear

    if [ -n "$choice" ]; then
        chosen_filename=$(echo "$filenames" | sed -n "$((choice + 1))p")
        echo "You chose: $chosen_filename"

        cd game/game_info || exit
        rm -f game_info.txt
        cp "$chosen_filename" game_info.txt
        cd ../..

chmod -R 0700 game
export LANG=pl_PL.UTF-8

export QUIET_MODE=1
#export XEPHYR_SIZE=1920x1280
#export XEPHYR_SIZE=0
export DISABLE_NET=0


cd game || exit
./start.sh &
cd ..

echo "Waiting for hl.exe to finish..."

# Wait until hl.exe appears, then wait until it disappears
while ! pgrep -i hl.exe >/dev/null; do
    sleep 1
done

while pgrep -i hl.exe >/dev/null; do
    sleep 2
done

echo "hl.exe finished. Cleaning up Wine processes..."
killall -q wineserver explorer.exe services.exe conhost.exe svchost.exe 2>/dev/null
pkill -9 winedevice.exe
pkill -9 plugplay.exe
pkill -9 winedevice.exe
pkill -9 tabtip.exe
pkill -9 rpcss.exe
pkill -9 cmd.exe





    else
        echo "No game selected. Exiting."
        bash ./game/script/set.sh
        exit 0
    fi
}

# Loop menu forever until user cancels
while true; do
    main_menu
done


