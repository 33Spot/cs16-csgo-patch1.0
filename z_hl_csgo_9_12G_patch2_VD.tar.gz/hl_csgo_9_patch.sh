resolution=$(xrandr | grep "*" | awk '{ print $1 }' | head -1)
width=$(xrandr | grep "*" | awk '{ print $1 }' | head -1 | sed 's/x/\n/g' | head -1)
height=$(xrandr | grep "*" | awk '{ print $1 }' | head -1 | sed 's/x/\n/g' | tail -1)
#sed -i -E "/^vd=/ { s/[0-9]+x[0-9]+[ ]*//; s/vd=[ ]*/vd=$resolution /; }" ./game/game_info/winetricks_list.txt -i

cd game
cd game_info
#sed -i '4c -w 960 -h 540' game_info.run
sed -i '4c -w '$width' -h '$height game_info.run
cd ..
cd ..

echo done
read r





