#!/bin/env bash

# Array of filenames
filenames="BotProfile.db_backup_relax
BotProfile.db_backup_online
BotProfile.db_backup_champion
botprofile.db_champion.1.3.1"

# Array of descriptions
descriptions="bots relaxed
bots like on online server
bots like on championships
bots like on championships 1.3.1"

# Create the menu options
i=0
options=""
while [ $i -lt $(echo "$filenames" | wc -l) ]; do
    filename=$(echo "$filenames" | sed -n "$((i + 1))p")
    description=$(echo "$descriptions" | sed -n "$((i + 1))p")
    options="$options $i \"$description\""
    i=$((i + 1))
done

# Show the dialog menu
choice=$(eval "dialog --menu 'Choose a filename' 11 55 16 $options 3>&1 1>&2 2>&3 3>&-")

# Clear the screen after dialog
clear

# Check if a valid choice was made
if [ -n "$choice" ]; then
    chosen_filename=$(echo "$filenames" | sed -n "$((choice + 1))p")
    echo "You chose: $chosen_filename"
    #echo "$chosen_filename" > chosen_filename.txt
    ##sed "/launch_/c\\$chosen_filename" ./game/game_info/game_info.txt -i

pushd "$(pwd)/game/game_info/data/Counter Strike 1.6 CSGO/cstrike"
rm -r BotProfile.db
cp $chosen_filename BotProfile.db
popd


else
    echo "No filename selected."
    exit
fi


